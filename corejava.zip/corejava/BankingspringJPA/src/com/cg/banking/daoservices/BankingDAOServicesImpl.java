package com.cg.banking.daoservices;
import com.cg.banking.services.*;
import com.cg.banking.utility.BankingUtility;
import java.util.Random;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.omg.PortableInterceptor.ACTIVE;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
@Component(value="BankingDAOServices")
public class BankingDAOServicesImpl implements BankingDAOServices{
	@Autowired
	private EntityManagerFactory entityManagerFactory;
 public BankingDAOServicesImpl() {
		
	}
	@Override
	public int insertCustomer(Customer customer) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer.getCustomerId();
	
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		account.setStatus("Active");
		Customer cust=getCustomer(customerId);
		account.setCustomer(cust);
		entityManager.persist(account);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		long accountNo = account.getAccountNo();
		Random rand = new Random();
		getAccount(customerId, accountNo).setPinNumber(rand.nextInt(9000)+1000);
		return getAccount(customerId, accountNo).getPinNumber();
		
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Account acct =getAccount(customerId, accountNo);
		acct.setAccountNo(accountNo);
		entityManager.persist(transaction);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
		
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.remove(entityManager.find(Customer.class, customerId));
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}
	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.remove(entityManager.find(Account.class, accountNo));
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Customer getCustomer(int customerId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return entityManager.find(Customer.class, customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return entityManager.find(Account.class,accountNo);
	}

	@Override
	public List<Customer> getCustomers() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query=entityManager.createQuery("from Customer c",Customer.class);		
		return query.getResultList();
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query=entityManager.createQuery("from Account a",Account.class);		
		return query.getResultList();
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query=entityManager.createQuery("from Transaction t",Transaction.class);		
		return query.getResultList();
	}
	}