package com.cg.banking.beans;
import java.util.HashMap;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.cg.banking.beans.Transaction;
@Entity
public class Transaction {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int transactionId;
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	private int timeStamp;
	private float amount;
	private String transactionType,transactionLocation,modeofTransaction,transactionStatus;
@ManyToOne
	private Account account;
	public Transaction() {}
	public Transaction(int transactionId, int timeStamp, float amount, String transactionType,
			String transactionLocation, String modeofTransaction, String transactionStatus,
			HashMap<Integer, Transaction> transactionList) {
		super();
		this.transactionId = transactionId;
		this.timeStamp = timeStamp;
		this.amount = amount;
		this.transactionType = transactionType;
		this.transactionLocation = transactionLocation;
		this.modeofTransaction = modeofTransaction;
		this.transactionStatus = transactionStatus;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(int timeStamp) {
		this.timeStamp = timeStamp;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionLocation() {
		return transactionLocation;
	}
	public void setTransactionLocation(String transactionLocation) {
		this.transactionLocation = transactionLocation;
	}
	public String getModeofTransaction() {
		return modeofTransaction;
	}
	public void setModeofTransaction(String modeofTransaction) {
		this.modeofTransaction = modeofTransaction;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", timeStamp=" + timeStamp + ", amount=" + amount
				+ ", transactionType=" + transactionType + ", transactionLocation=" + transactionLocation
				+ ", modeofTransaction=" + modeofTransaction + ", transactionStatus=" + transactionStatus
				+ "]";
	}
	public Transaction(float amount, String transactionType) {
		super();
		this.amount = amount;
		this.transactionType = transactionType;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(amount);
		result = prime * result + ((modeofTransaction == null) ? 0 : modeofTransaction.hashCode());
		result = prime * result + timeStamp;
		result = prime * result + transactionId;
		result = prime * result + ((transactionLocation == null) ? 0 : transactionLocation.hashCode());
		result = prime * result + ((transactionStatus == null) ? 0 : transactionStatus.hashCode());
		result = prime * result + ((transactionType == null) ? 0 : transactionType.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (Float.floatToIntBits(amount) != Float.floatToIntBits(other.amount))
			return false;
		if (modeofTransaction == null) {
			if (other.modeofTransaction != null)
				return false;
		} else if (!modeofTransaction.equals(other.modeofTransaction))
			return false;
		if (timeStamp != other.timeStamp)
			return false;
		if (transactionId != other.transactionId)
			return false;
		if (transactionLocation == null) {
			if (other.transactionLocation != null)
				return false;
		} else if (!transactionLocation.equals(other.transactionLocation))
			return false;
		if (transactionStatus == null) {
			if (other.transactionStatus != null)
				return false;
		} else if (!transactionStatus.equals(other.transactionStatus))
			return false;
		if (transactionType == null) {
			if (other.transactionType != null)
				return false;
		} else if (!transactionType.equals(other.transactionType))
			return false;
		return true;
	}
}