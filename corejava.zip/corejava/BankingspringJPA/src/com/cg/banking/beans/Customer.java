package com.cg.banking.beans;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.persistence.Column;
import javax.annotation.Generated;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.xml.bind.annotation.XmlRootElement;
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerId;
	public void setAccountList(Map<Long, Account> accountList) {
		this.accountList = accountList;
	}
	private int mobileNo,adharNo,dateOfBirth;
	private String firstName,lastName,emailId,pancardNo;

			@Embedded
			@AttributeOverrides({
			    @AttributeOverride(name="city",column=@Column(name="localCity")),
			    @AttributeOverride(name="state",column=@Column(name="localState")),
			    @AttributeOverride(name="pinCode",column=@Column(name="localPinCode")),
			    @AttributeOverride(name="country",column=@Column(name="localCountry"))
			})
			private Address localAddress; 
	@Embedded
	private Address homeAddress;
	@OneToMany(mappedBy="customer", cascade=CascadeType.ALL)
	@MapKey(name="accountNo")
	public Map<Long, Account> accountList = new HashMap<>();
	public Customer(){}
	public Customer(int customerId, int mobileNo, int adharNo, String pancardNo, int dateOfBirth, String firstName,
			String lastName, String emailId, HashMap<Long, Account> accountList, Address localAddress,
			Address homeAddress) {
		super();
		this.customerId = customerId;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.pancardNo = pancardNo;
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.accountList = accountList;
		this.localAddress = localAddress;
		this.homeAddress = homeAddress;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(int adharNo) {
		this.adharNo = adharNo;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public int getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(int dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Map<Long, Account> getAccountList() {
		return accountList;
	}
	public void setAccountList(HashMap<Long, Account> accountList) {
		this.accountList = accountList;
	}
	public Address getLocalAddress() {
		return localAddress;
	}
	public void setLocalAddress(Address localAddress) {
		this.localAddress = localAddress;
	}
	public Address getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", mobileNo=" + mobileNo + ", adharNo=" + adharNo + ", pancardNo="
				+ pancardNo + ", dateOfBirth=" + dateOfBirth + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailId=" + emailId + ", accountList=" + accountList + ", localAddress=" + localAddress
				+ ", homeAddress=" + homeAddress + "]";
	}
	public Customer(String pancardNo, String firstName, String lastName, String emailId,
			 Address localAddress, Address homeAddress) {
		super();
		this.pancardNo = pancardNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.localAddress = localAddress;
		this.homeAddress = homeAddress;
	}
	
}