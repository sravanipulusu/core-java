package com.cg.payroll.test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class PayrollServicesTest {

private static PayrollServices payrollservices;
	private static PayrollDAOServices mockDaoServices;
	@BeforeClass
		public static void setUpPayrollServices(){
		mockDaoServices = Mockito.mock(PayrollDAOServices.class);
			payrollservices=new PayrollServicesImpl(mockDaoServices);
	}

	@Before
		public void setUpMockData() {
		
		Associate associate1= new Associate( 112,150000, "SRAVANI","pulusu", "java", "btech", "dfdfdfd", "sdfsf@gdfg",new salary(30000, 1000,1000), new BankDetails(54564546, "citi", "citi000076"));
	    Associate associate2= new Associate(113,150000, "prabha","buduri", "sap", "btech", "dfdfdfd", "sdfsf@gdfg", new salary(30000, 1000, 1000),new BankDetails(50064546, "citi", "citi000076"));
	    Associate associate3= new Associate( 114,15000, "bhargav","kommireddy", "java", "btech", "dfdfdfd", "sdfsf@gdfg", new salary(50000, 1000, 1000) ,new BankDetails(54564546, "citi", "citi000076"));
	    Associate associate4 = new Associate(15000, "ravi", "pulusu", "asdsd", "erre", "fedr45f", "adsdsers", new BankDetails(6565656, "hdfc", "45454"),new salary(56000, 1000,1000));
	  	
	    Mockito.when(mockDaoServices.getAssociate(112)).thenReturn(associate1);
	    Mockito.when(mockDaoServices.getAssociate(113)).thenReturn(associate2);
	    Mockito.when(mockDaoServices.getAssociate(114)).thenReturn(associate3);
	    Mockito.when(mockDaoServices.insertAssociate(associate4)).thenReturn(115);
	}
	@Test
	public void testForAcceptAssociateDetailsForValidAssociateId() throws AssociateDetailsNotFoundException{
	payrollservices.acceptAssociateDetails(150000,"SRAVANI" , "pulusu", "java", "btech", "dfdfdfd", "sdfsf@gdfg", 54564546, "citi","citi000076" ,30000, 1000,1000);
	assertEquals(115, payrollservices.getAssociateDetails());
	}
	/*@Test(expected=AssociateDetailsNotFoundException.class)
	
	
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	
		
	@Test
	public void testForDeleteAssociateforvalidAssociateId() throws AssociateDetailsNotFoundException{
			
		}
	@Test(expected=AssociateDetailsNotFoundException.class)
	
	}
	@Test
	{

	}
	*/
	@After
	public void tearDownMockData()
	{
		
	
	//PayrollDAOServicesImpl.associateList.clear();
	}
	@AfterClass
	public static void tearDownTestEnv() {
		payrollservices = null;
	}

}
