package com.cg.project.services;

import com.cg.project.exceptions.InValidNoRangeException;

public class MainClass {

	public static void main(String[] args) throws InValidNoRangeException {
		
		MathServices mathservices = new MathServicesImpl();
		System.out.println(mathservices.add(305, 206));
		System.out.println(mathservices.sub(30, 20));
		System.out.println(mathservices.div(30, 2));
		
		
		

	}

}
