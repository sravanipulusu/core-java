package com.cg.onlinecab.beans;

public class Passenger {
		private String name;
			private long mobileNo
			

}
