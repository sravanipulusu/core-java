package com.cg.payroll.daoservices;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.omg.CORBA.OBJ_ADAPTER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.utility.AssociateMapper;
import com.cg.payroll.utility.PayrollUtility;
import java.sql.PreparedStatement;
@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired
	private SessionFactory sessionFactory;
	

	@Override
	public int insertAssociate(Associate associate)  {
		Session session=sessionFactory.openSession();
		int associateId=(int)session.save(associate);
		session.close();
		return associateId;
	}

	@Override
	public boolean updateAssociate(Associate associate)  {
		Session session=sessionFactory.openSession();
		session.update(associate);
		session.flush();
		return true;
	}

	@Override
	public boolean deleteAssociate(int associateId) {
		sessionFactory.openSession().delete(getAssociate(associateId));		
		sessionFactory.openSession().close();
		return true;
	
	}

	@Override
	public Associate getAssociate(int associateId) {
		Session session=sessionFactory.openSession();
		Associate associate=(Associate) session.get(Associate.class, associateId);
		return associate;
	}

	@Override
	public List<Associate> getAssociates() {
		//Session session=sessionFactory.openSession();
		Query query=sessionFactory.openSession().createQuery("from Associate a");
		return query.list();
	
	
	}

	@Override
	public int save(Associate associate) {
		
		return 0;
	}

}

