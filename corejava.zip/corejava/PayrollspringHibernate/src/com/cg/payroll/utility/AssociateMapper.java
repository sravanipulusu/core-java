package com.cg.payroll.utility;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cg.payroll.beans.Associate;

public class AssociateMapper implements RowMapper<Associate> {

	@Override
	public Associate mapRow(ResultSet resultSet, int i) throws SQLException {
		Associate associate=new Associate();
		associate.setAssociateId(resultSet.getInt(1));
		return associate;
	}

}

