package com.cg.project.services;

import org.springframework.stereotype.Component;

@Component("greetingServices")
public class GreetingServicesNewImpl implements GreetingServices {
	public String sayHello(String name) {
		
		return  "hi" +name;
	}

	@Override
	public String sayGoodbye(String name) {
		
		return "bye" +name;
	}

}
