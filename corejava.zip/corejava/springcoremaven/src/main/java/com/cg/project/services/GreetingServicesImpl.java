package com.cg.project.services;

import org.springframework.stereotype.Component;

@Component("greetingServices")
public class GreetingServicesImpl implements GreetingServices {

	@Override
	public String sayHello(String name) {
	return	"hello " + name +"!!";
		
	}

	@Override
	public String sayGoodbye(String name) {
		
		return "GoodBye" + name;
	}

	
}
