package com.cg.project.services;

public interface GreetingServices {
	public String sayHello(String name);
	public String sayGoodbye(String name);
}
