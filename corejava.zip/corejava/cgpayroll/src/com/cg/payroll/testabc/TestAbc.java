package com.cg.payroll.testabc;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestAbc {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
