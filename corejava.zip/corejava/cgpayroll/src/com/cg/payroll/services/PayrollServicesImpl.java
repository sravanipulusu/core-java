package com.cg.payroll.services;
import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.exception.*;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
public class PayrollServicesImpl implements PayrollServices {
	private float annualTax;
	private PayrollDAOServices daoServices;
	
	public PayrollServicesImpl() {
		daoServices = new PayrollDAOServicesImpl();
	}

	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#acceptAssociateDetails(int, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int, java.lang.String, java.lang.String, int, int, int)
	 */
	@Override
	public int acceptAssociateDetails(int yearlyInvestmentUnder80C,String firstName,String lastName,String department,
			String designation,String pancard, String emailId, int accountNumber,
			String bankName , String ifscCode, int basicSalary, int epf,int companyPf) {

		return daoServices.insertAssociate( (new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new BankDetails(accountNumber, bankName, ifscCode), new salary(basicSalary, epf, companyPf))));
	}
		public boolean updateAssociateDetails(int associateId,String firstName, String lastName, String department, String emailId,
					String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
					int accountNumber, String bankName, String ifscCode)throws AssociateDetailsNotFoundException {
				boolean a= daoServices.updateAssociate(new Associate(associateId,yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));	
				if(a==false)
					throw new AssociateDetailsNotFoundException("Associate details of associateId"+associateId+"not found");
			return a;
			 } 
		 public boolean deleteAssociate(int associateId)throws AssociateDetailsNotFoundException{
				 boolean a= daoServices.deleteAssociate(associateId);
				 if(a==false)
						throw new AssociateDetailsNotFoundException("Associate details of associateId"+associateId+"not found");
				return a; 
			 } 

	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#calculateNetSalary(int)
	 */
	@Override
	public float calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException{
			if(getAssociateDetails(associateId)!=null) {
				Associate associate=getAssociateDetails(associateId);
				associate.getSalary1().setPersonalAllowance(0.3f*associate.getSalary1().getBasicSalary());
				associate.getSalary1().setConveyenceAllowance(0.2f*associate.getSalary1().getBasicSalary());
				associate.getSalary1().setOtherAllowance(0.1f*associate.getSalary1().getBasicSalary());
				associate.getSalary1().setHra(0.25f*associate.getSalary1().getBasicSalary());
				associate.getSalary1().setGratuity(0.05f*associate.getSalary1().getBasicSalary());
				associate.getSalary1().setGrossSalary(associate.getSalary1().getBasicSalary()+associate.getSalary1().getCompanyPf()+associate.getSalary1().getConveyenceAllowance()+associate.getSalary1().getPersonalAllowance()+associate.getSalary1().getOtherAllowance()+associate.getSalary1().getHra());
				float annualSalary=12*associate.getSalary1().getGrossSalary();
				if((associate.getYearlyInvestmentUnder80C()+(12*associate.getSalary1().getCompanyPf())+(12*associate.getSalary1().getEpf())<=150000)) {
					if(annualSalary>=1000000) {
						annualTax=(annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000)+0.1f*(150000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary1().getCompanyPf())-(12*associate.getSalary1().getEpf()));
					}
					else if(annualSalary>=500000&&annualSalary<100000) 
						annualTax=(0.2f*(annualSalary-500000)+(0.1f*(150000-(associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary1().getEpf()+12*associate.getSalary1().getCompanyPf())))));
					else if(annualSalary<500000 && annualSalary>=250000)
						if(annualSalary-250000>(associate.getYearlyInvestmentUnder80C()+associate.getSalary1().getCompanyPf()+associate.getSalary1().getEpf()))
							annualTax=0.1f*(annualSalary-250000-associate.getYearlyInvestmentUnder80C()-(12*associate.getSalary1().getEpf()-12*associate.getSalary1().getCompanyPf()));
						else 
							annualTax=0;
					else if(annualSalary<250000)
						annualTax=0;
				}
				else {
					if(annualSalary>=1000000) 
						annualTax=((annualSalary-1000000)*0.3f+(0.2f*500000)+(0.1f*100000));
					else if(annualSalary>=500000&&annualSalary<1000000)
						annualTax=(0.2f*(annualSalary-500000)+(0.1f*100000));
					else if(annualSalary<500000 && annualSalary>=250000)
						annualTax=(0.1f*(100000));
					else
						annualTax=0;
				}
				associate.getSalary1().setMonthlyTax(annualTax/12);
				associate.getSalary1().setNetSalary(associate.getSalary1().getGrossSalary()-associate.getSalary1().getMonthlyTax()-associate.getSalary1().getCompanyPf()-associate.getSalary1().getEpf());
			return associate.getSalary1().getNetSalary();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
			}
			return associateId;
	}
	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAssociateDetails(int)
	 */
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException{	

		if(associateId!=0) {
			throw new AssociateDetailsNotFoundException("Associate details of associate " + associateId +"NOT FOUND");
		}
		return daoServices.getAssociate(associateId);	
	}

	/* (non-Javadoc)
	 * @see com.cg.payroll.services.PayrollServices#getAssociateDetails()
	 */
	@Override
	public List<Associate> getAssociateDetails() {
		return daoServices.getAssociates();
	}
}
