package com.cg.payroll.daoservices;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.utility.PayrollUtility;
public class PayrollDAOServicesImpl implements PayrollDAOServices {

	public static HashMap<Integer, Associate> associateList = new HashMap<>();
	//private static int ASSOCIATE_ID_COUNTER = 111;
	
	@Override
	public int insertAssociate(Associate associate){
		associateList.put(PayrollUtility.ASSOCIATE_ID_COUNTER, associate);
		associate.setAssociateId(PayrollUtility.ASSOCIATE_ID_COUNTER++);
		return associate.getAssociateId();
		
	}

	@Override
	public boolean updateAssociate(Associate associate){
		associateList.put(associate.getAssociateId(), associate);
		return true;
	}

	@Override
	public boolean deleteAssociate(int associateId){
		Associate a =associateList.remove(associateId);
		if(a==null) return false;
				return true;
	}
	
	@Override
	public Associate getAssociate(int associateId){
	
				return associateList.get(associateId);
		}
	
	@Override
	public List<Associate> getAssociates(){
		List<Associate> list = new ArrayList<>(associateList.values());
		return list;
		}
}

