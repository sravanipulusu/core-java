package com.cg.payroll.daoservices;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.utility.PayrollUtility;
import java.sql.PreparedStatement;
@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	private Connection con=null;
	final String INSERT_QUERY = "insert into associate (name, ) values (?, ?)";
	/*public PayrollDAOServicesImpl() throws PayrollServicesDownException{
		//con=PayrollUtility.getDBConnection();
	}*/
	@Override
	public int insertAssociate(Associate associate) throws SQLException {
		try { 
			con.setAutoCommit(false);
			PreparedStatement pstmt1 = con.prepareStatement("insert into Associate (yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId) value(?,?,?,?,?,?,?)"); 
			pstmt1.setInt(1, associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2, associate.getFirstName());
			pstmt1.setString(3, associate.getLastName());
			pstmt1.setString(4, associate.getDepartment());
			pstmt1.setString(5, associate.getDesignation());
			pstmt1.setString(6, associate.getPancard());
			pstmt1.setString(7, associate.getEmailId());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2 = con.prepareStatement("select max(associateId) from Associate");
			
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int associateId = rs.getInt(1);
			
			PreparedStatement pstmt3 = con.prepareStatement("insert into Salary(associateId,basicSalary,epf,companyPf) values(?,?,?,?)");
			pstmt3.setInt(1, associateId);
			pstmt3.setFloat(2, associate.getSalary1().getBasicSalary());
			pstmt3.setFloat(3, associate.getSalary1().getEpf());
			pstmt3.setFloat(4, associate.getSalary1().getCompanyPf());
			pstmt3.executeUpdate();
			
			PreparedStatement pstmt4 = con.prepareStatement("insert into BankDetails(associateId,accountNumber,bankName,ifscCode)values(?,?,?,?)");
			pstmt4.setInt(1, associateId);
			pstmt4.setInt(2, associate.getBankDetails().getAccountNumber());
			pstmt4.setString(3, associate.getBankDetails().getBankName());
			pstmt4.setString(4, associate.getBankDetails().getIfscCode());
		
			pstmt4.executeUpdate();
			con.commit();
			return associateId;
		}
		catch (SQLException e) {
			con.rollback();
			throw e;
		}
		finally {
			con.setAutoCommit(true);
		}
		
	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException{
		try { 
			con.setAutoCommit(false);
			PreparedStatement pstmt1 = con.prepareStatement("update Associate (yearlyInvestmentUnder80C=?,firstName=?,lastName=?,department=?,designation=?,pancard=?,emailId=?) where associateId=?"); 
			pstmt1.setInt(1, associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2, associate.getFirstName());
			pstmt1.setString(3, associate.getLastName());
			pstmt1.setString(4, associate.getDepartment());
			pstmt1.setString(5, associate.getDesignation());
			pstmt1.setString(6, associate.getPancard());
			pstmt1.setString(7, associate.getEmailId());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2 = con.prepareStatement("select max(associateId) from Associate");
			
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int associateId = rs.getInt(1);
			
			PreparedStatement pstmt3 = con.prepareStatement("update Salary(basicSalary=?,epf=?,companyPf=?,hra=?, conveyenceAllowance=?, otherAllowance=?, monthlyTax=?,gratuity=?,  personalAllowance=? grossSalary=?,  netSalary=?) where asssociateId=?");
			pstmt3.setFloat(1, associate.getSalary1().getBasicSalary());
			pstmt3.setFloat(2, associate.getSalary1().getEpf());
			pstmt3.setFloat(3, associate.getSalary1().getCompanyPf());
			pstmt3.setFloat(4, associate.getSalary1().getHra());
			pstmt3.setFloat(5,associate.getSalary1().getConveyenceAllowance());
			pstmt3.setFloat(6, associate.getSalary1().getOtherAllowance());
			pstmt3.setFloat(7, associate.getSalary1().getMonthlyTax());
			pstmt3.setFloat(8, associate.getSalary1().getGratuity());
			pstmt3.setFloat(9, associate.getSalary1().getPersonalAllowance());
			pstmt3.setFloat(10, associate.getSalary1().getGrossSalary());
			pstmt3.setFloat(11, associate.getSalary1().getNetSalary());
			pstmt3.setInt(12, associate.getAssociateId());
			pstmt3.executeUpdate();
			
			PreparedStatement pstmt4 = con.prepareStatement("update BankDetails(accountNumber=?,bankName=?,ifscCode=?) where associateId=?");
			pstmt4.setInt(1, associateId);
			pstmt4.setInt(2, associate.getBankDetails().getAccountNumber());
			pstmt4.setString(3, associate.getBankDetails().getBankName());
			pstmt4.setString(4, associate.getBankDetails().getIfscCode());
		
			pstmt4.executeUpdate();
			con.commit();
			return true;
		}
		catch (SQLException e) {
			con.rollback();
			throw e;
		}
		finally {
			con.setAutoCommit(true);
		}
	}

	@Override
	public boolean deleteAssociate(int asscociateId) {
	
		return false;
	}

	@Override
	public Associate getAssociate(int associateId) {
		
		return null;
	}

	@Override
	public List<Associate> getAssociates() {
		
		return null;
	}
	

}

