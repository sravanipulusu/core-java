package com.cg.payroll.main;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.payroll.services.PayrollServices;
public class MainClass {
	public static void main(String[] args) {
			ApplicationContext applicationContext = new ClassPathXmlApplicationContext("projectbeans.xml");
			PayrollServices services =(PayrollServices)applicationContext.getBean("PayrollServices");
					
			
			
			
			
			
			
			
			/*PayrollServices services = new PayrollServicesImpl();
			services.acceptAssociateDetails(15000, "srvani", "pulusu", "java", "btech", "45fgfg", "sravanysany@gmail.com", 8758784, "citi", "citi000008", 300000, 1000, 1000);
			
		}
		catch(PayrollServicesDownException c) {
			c.printStackTrace();
		}*/
	
	/*try{
		PayrollServices payrollservices = new PayrollServicesImpl();
		int i=payrollservices.acceptAssociateDetails(150000, "sravani", "pulusu", "java", "btech", "sd4545", "sdsd@.com", 99999, "hdfc", "sdsds", 30000, 1000, 1000);
	
	System.out.println(payrollservices.calculateNetSalary(i));
	Associate a1=payrollservices.getAssociateDetails(i);
	System.out.println("gross salary is" + a1.getSalary1().getGrossSalary() +"\n"+a1.getFirstName()+"\n"+a1.getLastName()+ "\n" +"net salary is" + a1.getSalary1().getNetSalary());
	System.out.println("monthly tax is" + a1.getSalary1().getMonthlyTax());
	
	PayrollServices payrollservices1 = new PayrollServicesImpl();
	int j=payrollservices1.acceptAssociateDetails(150000, "prasanna", "kumar", "sap", "btech", "sd4545", "bhargav@.com", 999090, "hdfc", "sdsds", 34000, 1000, 1000);
	System.out.println(j);
	System.out.println(payrollservices1.calculateNetSalary(j));
	Associate a2=payrollservices1.getAssociateDetails(j);	
	System.out.println( a2.getFirstName() +"\n" + a2.getLastName()+"\n"+"gross salary is:" + a2.getSalary1().getGrossSalary()+  "\n" +"net salary is" + a2.getSalary1().getNetSalary() );
	System.out.println("monthly tax is" + a2.getSalary1().getMonthlyTax());
	
	PayrollServices payrollservices2 = new PayrollServicesImpl();
	int k=payrollservices2.acceptAssociateDetails(150000, "bhargav", "kommireddy", "java", "btech", "sd4545", "bhargav@.com", 999090, "hdfc", "sdsds", 44000, 1000, 1000);
	System.out.println(k);
	System.out.println(payrollservices2.calculateNetSalary(k));
	Associate a3=payrollservices2.getAssociateDetails(k);
	System.out.println(a3.getFirstName() +"\n" + a3.getLastName()+"\n"+"gross salary is:" + a3.getSalary1().getGrossSalary()+ "\n" + "net salary is" + a3.getSalary1().getNetSalary() );
	System.out.println("monthly tax is" + a3.getSalary1().getMonthlyTax());

	}
	catch(Exception e) {
		System.out.println("error");
	}
	}*/
	}
}

	

