package com.cg.airreservation.beans;

public class Cancellation {
	private String lastDateForCancellation,percentageofCancellation;
	private int amountRefunded; 
	public Cancellation() {}
	public Cancellation(String lastDateForCancellation, String percentageofCancellation, int amountRefunded) {
		super();
		this.lastDateForCancellation = lastDateForCancellation;
		this.percentageofCancellation = percentageofCancellation;
		this.amountRefunded = amountRefunded;
	}
	public String getLastDateForCancellation() {
		return lastDateForCancellation;
	}
	public void setLastDateForCancellation(String lastDateForCancellation) {
		this.lastDateForCancellation = lastDateForCancellation;
	}
	public String getPercentageofCancellation() {
		return percentageofCancellation;
	}
	public void setPercentageofCancellation(String percentageofCancellation) {
		this.percentageofCancellation = percentageofCancellation;
	}
	public int getAmountRefunded() {
		return amountRefunded;
	}
	public void setAmountRefunded(int amountRefunded) {
		this.amountRefunded = amountRefunded;
	}
	
}
