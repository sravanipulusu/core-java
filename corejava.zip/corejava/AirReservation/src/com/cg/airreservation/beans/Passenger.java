package com.cg.airreservation.beans;

public class Passenger {
	private String firstName,lastName;
	private long mobileNumber,adharNumber;
	private TicketDetails[] ticketdetails;
	public Passenger() {}
	public Passenger(String firstName, String lastName, long mobileNumber, long adharNumber,
			TicketDetails[] ticketdetails) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.adharNumber = adharNumber;
		this.ticketdetails = ticketdetails;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public long getAdharNumber() {
		return adharNumber;
	}
	public void setAdharNumber(long adharNumber) {
		this.adharNumber = adharNumber;
	}
	public TicketDetails[] getTicketdetails() {
		return ticketdetails;
	}
	public void setTicketdetails(TicketDetails[] ticketdetails) {
		this.ticketdetails = ticketdetails;
	}

}
