package com.cg.airreservation.beans;

public class TicketDetails {
		 private String ticketNo,boardPoint,dropPoint,startTime,arrivalTime,typeOfClass;
		 private Transaction transaction;
		 private Cancellation cancellation; 
		 public TicketDetails() {}
		public TicketDetails(String ticketNo, String boardPoint, String dropPoint, String startTime, String arrivalTime,
				String typeOfClass, Transaction transaction, Cancellation cancellation) {
			super();
			this.ticketNo = ticketNo;
			this.boardPoint = boardPoint;
			this.dropPoint = dropPoint;
			
			
			
			this.startTime = startTime;
			this.arrivalTime = arrivalTime;
			this.typeOfClass = typeOfClass;
			this.transaction = transaction;
			this.cancellation = cancellation;
		}
		public String getTicketNo() {
			return ticketNo;
		}
		public void setTicketNo(String ticketNo) {
			this.ticketNo = ticketNo;
		}
		public String getBoardPoint() {
			return boardPoint;
		}
		public void setBoardPoint(String boardPoint) {
			this.boardPoint = boardPoint;
		}
		public String getDropPoint() {
			return dropPoint;
		}
		public void setDropPoint(String dropPoint) {
			this.dropPoint = dropPoint;
		}
		public String getStartTime() {
			return startTime;
		}
		public void setStartTime(String startTime) {
			this.startTime = startTime;
		}
		public String getArrivalTime() {
			return arrivalTime;
		}
		public void setArrivalTime(String arrivalTime) {
			this.arrivalTime = arrivalTime;
		}
		public String getTypeOfClass() {
			return typeOfClass;
		}
		public void setTypeOfClass(String typeOfClass) {
			this.typeOfClass = typeOfClass;
		}
		public Transaction getTransaction() {
			return transaction;
		}
		public void setTransaction(Transaction transaction) {
			this.transaction = transaction;
		}
		public Cancellation getCancellation() {
			return cancellation;
		}
		public void setCancellation(Cancellation cancellation) {
			this.cancellation = cancellation;
		}
		 
		 


}
