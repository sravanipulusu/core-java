package com.cg.io.main;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreamDemo {
	public static void byteReadWriteWork(File fromFile,File toFile) throws IOException{
		FileInputStream src = new FileInputStream(fromFile);
		FileOutputStream dest = new FileOutputStream(toFile);
		int a=0;
		while((a=src.read())!=-1) {
			System.out.print((char)a);
		}
		byte[]dataBuffer = new byte[(int) fromFile.length()];
		src.read(dataBuffer);
		dest.write(dataBuffer);
	}

}
