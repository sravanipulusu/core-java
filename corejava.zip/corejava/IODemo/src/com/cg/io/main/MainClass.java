package com.cg.io.main;

import java.io.File;
import java.io.IOException;
public class MainClass {
	public static void main(String[] args) {
	try
	{
		File fromFile = new File("d:\\FLPDATAFILE.txt");
		File toFile = new File("d:\\destfile.txt");
		if(!toFile.exists())
		toFile.createNewFile();
				/*System.out.println(file.length());
				System.out.println(file.canRead());
			System.out.println(file.canWrite());*/
		ByteStreamDemo.byteReadWriteWork(fromFile, toFile);
	}
		catch(IOException e) {
			e.printStackTrace();
		}
	}	
}
