package com.cg.io.main;

public class Associate {

}
