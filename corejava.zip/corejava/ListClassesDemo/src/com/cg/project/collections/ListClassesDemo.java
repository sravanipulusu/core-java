package com.cg.project.collections;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
public class ListClassesDemo {
	public static void arrayListClassWork() {
			ArrayList<String>strList = new ArrayList<>();
			//insertion
			strList.add("sravani");
			strList.add("prabha");
			strList.add("bhargav");
			strList.add("ravi");
			strList.add("vishnu");
			
			//iteration
			Iterator<String> iterator =strList.iterator();
			while(iterator.hasNext()) {
				String string = iterator.next();
			}
			//search
			System.out.println(strList.contains("prabha"));
			
			//sort
			Collections.sort(strList);
			System.out.println(strList);
			
			ArrayList<Customer>customerList=new ArrayList<>();
			customerList.add(new Customer(001, "sravani", "pulusu"));
			customerList.add(new Customer(002, "ravi", "pulusu"));
			customerList.add(new Customer(003, "bhargav", "kommireddy"));
		
			Collections.sort(customerList, new CustomerComparator());
			for(Customer cust : customerList) {
				System.out.println(cust);
			}
	}
}
