package com.cg.project.collections;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Customer {
	private static int customerId;
	private String firstName,lastName;
	public Customer() {}
	public Customer(int customerId, String lastName2, String string) {
		super();
		this.customerId=customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		
	}

	public static int getCustomerId() {
		return customerId;
	}

	public static void setCustomerId(int customerId) {
		Customer.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public ArrayList<String> getIntList() {
		return intList;
	}

	public void setIntList(ArrayList<String> intList) {
		this.intList = intList;
	}

	ArrayList<String> intList = new ArrayList<>();
	
	public int compareTo(Customer customer) {
		
		return this.customerId-customer.customerId;
		
	}
	@Override
	public String toString() {
		return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", intList=" + intList + "]";
	}
	

}
