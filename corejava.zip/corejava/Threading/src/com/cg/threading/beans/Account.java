package com.cg.threading.beans;

public class Account {
	private static int SUCCESS,FAIL=0;
	private volatile int balance;
	public Account(){}
	public Account(int balance) {
		super();
		this.balance = balance;
	}
	public int getBalance() {
		return balance;
	}
	public  void setBalance(int balance) {
		this.balance = balance;
	}
	public synchronized int deposit(int amount){
		balance=balance+amount;
		this.notify();
		//this.notifyAll();
		return balance;
	}
	public synchronized int withdraw(int amount) throws InterruptedException{
		if(balance<0||(getBalance()-amount)<0){
			FAIL++;
		System.out.println("\n\tWithdraw Fail "+FAIL);
		this.wait(8000);
		return balance;
	}
		else{
			balance=balance-amount;
			SUCCESS++;
			System.out.println("\n\tWithdraw Success "+ SUCCESS);
			return balance;
		}
	}
}

