package com.cg.threading.beans;

public class Customer implements Runnable {
	public Customer(){}
	private static Account account;
	static{
		account=new Account(10000);
		System.out.println("Initial Balance  :-"+account.getBalance()+"\n\n====================");
		}
	@Override
	public void run(){
		Thread customerThread=Thread.currentThread();
		if(customerThread.getName().equals("Rahul")){
			for(int i=0;i<10;i++){
				try{
					Thread.sleep(0);
					System.out.println("\n Rahul has call to withdraw"+i
							+"time balance:="+account.withdraw(3000));
				}catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	
	if(customerThread.getName().equals("Ravi")){
		for(int i=0;i<10;i++){
			try{
				Thread.sleep(0);
				System.out.println("\n Ravi has call to deposit"+i
						+"time balance:="+account.deposit(2000));
			}catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	if(customerThread.getName().equals("satish")){
		for(int i=0;i<10;i++){
			try{
				Thread.sleep(0);
				System.out.println("\n satish has checked balance"+i
						+"time balance:="+account.getBalance());
			}catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	}

}


