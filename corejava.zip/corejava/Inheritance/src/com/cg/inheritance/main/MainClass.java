package com.cg.inheritance.main;

import com.cg.inheritance.beans.*;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	Employee employee = new Employee(111,15000,"sravani","pulusu");
		employee.calculateSalary();
		System.out.println(employee.getTotalSalary() );
		
		PEmployee pemployee = new PEmployee(112,25000,"s","p");
		pemployee.calculateSalary();
		System.out.println(pemployee.toString());
		
		CEmployee cemployee = new CEmployee(113, 8,"sra", "pul");
		cemployee.calculateSalary();
		System.out.println(cemployee.toString());
		*/
		Employee employee = new CEmployee(1222,23000,"sravani", "pulusu",6);
		employee.calculateSalary();
		CEmployee cEmployee=(CEmployee) employee;
		System.out.println(cEmployee.getVariablePay());
		
		
		
		
		
		
		
	}

}
