package com.cg.inheritance.beans;

public final class CEmployee extends Employee{
	private int hrs,variablePay;

	public CEmployee() {
		super();		
	}
	

	public CEmployee(int employeeId, int basicSalary, String firstName, String lastName, int hrs ) {
		super(employeeId, basicSalary, firstName, lastName);
		this.hrs=hrs;
		
	}

	public int getHrs() {
		return hrs;
	}

	public void setHrs(int hrs) {
		this.hrs = hrs;
	}

	public int getVariablePay() {
		return variablePay;
	}

	public void setVariablePay(int variablePay) {
		this.variablePay = variablePay;
	}
	public void calculateSalary(){
		this.setVariablePay(hrs*20000);
	}


	@Override
	public String toString() {
		return "CEmployee [hrs=" + hrs + ", variablePay=" + variablePay + ", getEmployeeId()=" + getEmployeeId()
				+ ", getBasicSalary()=" + getBasicSalary() + ", getFirstName()=" + getFirstName() + ", getLastName()="
				+ getLastName() + ", getTotalSalary()=" + getTotalSalary() + "]";
	}
	
}



