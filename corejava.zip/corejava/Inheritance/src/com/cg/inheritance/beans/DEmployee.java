package com.cg.inheritance.beans;

public final class DEmployee extends PEmployee {
	private int incentive,projects;
	public DEmployee() {
		super();
	}
	public DEmployee(int incentive, int projects) {
		super();
		this.incentive = incentive;
		this.projects = projects;
	}
	public int getIncentive() {
		return incentive;
	}
	public void setIncentive(int incentive) {
		this.incentive = incentive;
	}
	public int getProjects() {
		return projects;
	}
	public void setProjects(int projects) {
		this.projects = projects;
	}
	public void calculateSalary(){
		super.calculateSalary();
		this.incentive=this.projects*80000;
		this.setTotalSalary(incentive+this.getTotalSalary());
	}
	@Override
	public String toString() {
		return super.toString()+"Developer [noOfProjects=" + projects + ", incentive=" + incentive + "]";
	}

}
