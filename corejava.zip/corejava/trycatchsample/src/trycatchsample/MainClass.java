package trycatchsample;
import java.util.InputMismatchException;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		try {
			Scanner scanner =new Scanner(System.in);
			System.out.println("Enter first number");
			int n1=scanner.nextInt();
			System.out.println("enter second number");
			int n2=scanner.nextInt();
			System.out.println(n1/n2);
			System.out.println("Arithmetic task completed here");}
		catch(InputMismatchException e) {
			e.printStackTrace();
			System.out.println("enter only integer");
		}
		catch(ArithmeticException e) {
			e.printStackTrace();
			System.out.println("arithmetic  error in code");
			
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("inside exception");
		}
		System.out.println("After try catch block");
		}
		}
	

