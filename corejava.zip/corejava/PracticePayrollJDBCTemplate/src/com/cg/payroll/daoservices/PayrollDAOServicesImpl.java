package com.cg.payroll.daoservices;
import java.util.List;

import org.omg.CORBA.OBJ_ADAPTER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.utility.AssociateMapper;
import com.cg.payroll.utility.PayrollUtility;
import java.sql.PreparedStatement;
@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {  
	     this.jdbcTemplate = jdbcTemplate;  
	 }
	public int insertAssociate(Associate associate) throws SQLException {
		String sql="insert into associate(yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId) value(?,?,?,?,?,?,?)";
		jdbcTemplate.update(sql, associate.getYearlyInvestmentUnder80C(), associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId());
		String sql1="select max(associateId) from associate";
		List<Associate> a=jdbcTemplate.query(sql1, new AssociateMapper());
		int b=a.get(0).getAssociateId();
		
		String sql2="insert into bankdetails(associateId,accountNumber,bankName,ifscCode)values(?,?,?,?) ";
		jdbcTemplate.update(sql2,b,associate.getBankDetails().getAccountNumber(),associate.getBankDetails().getBankName(),associate.getBankDetails().getIfscCode());
		
		String sql3="insert into salary(associateId,basicSalary,epf,companyPf) values(?,?,?,?)";
		jdbcTemplate.update(sql3,b,associate.getSalary1().getBasicSalary(),associate.getSalary1().getEpf(),associate.getSalary1().getCompanyPf());
		return b;
	}
		
	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {

		String sql="update associate set yearlyInvestmentUnder80C=?,firstName=?,lastName=?,department=?,designation=?,pancard=?,emailId=? where associateId=?";
		jdbcTemplate.update(sql, associate.getYearlyInvestmentUnder80C(), associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId(),associate.getAssociateId());
		String sql2="update bankdetails set accountNumber=?,bankName=?,ifscCode=? where associateId=?";
		jdbcTemplate.update(sql2,associate.getBankDetails().getAccountNumber(),associate.getBankDetails().getBankName(),associate.getBankDetails().getIfscCode(),associate.getAssociateId());
		String sql3="update salary set basicSalary=?,hra=?,conveyenceAllowance=?,otherAllowance=?,personalAllowance=?,monthlyTax=?,epf=?,companyPf=?,gratuity=?,grossSalary=?,netSalary=? where associateId=?";
		jdbcTemplate.update(sql3,associate.getSalary1().getBasicSalary(),associate.getSalary1().getHra(),associate.getSalary1().getConveyenceAllowance(),associate.getSalary1().getOtherAllowance(),associate.getSalary1().getPersonalAllowance(),associate.getSalary1().getMonthlyTax(),associate.getSalary1().getEpf(),associate.getSalary1().getCompanyPf(),associate.getSalary1().getGratuity(),associate.getSalary1().getGrossSalary(),associate.getSalary1().getNetSalary(),associate.getAssociateId());
	 return true;
		        
	}

	@Override
	public boolean deleteAssociate(int asscociateId) {
	
		return false;
	}

	@Override
	public Associate getAssociate(int associateId) {
		String str="select a.associateId,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,\r\n"+
				"b.accountNumber,b.bankName,b.ifscCode,\r\n"+
				 "c.basicSalary,c.hra,c.conveyenceAllowance,c.otherAllowance,c.personalAllowance,c.monthlyTax,c.epf,c.companyPf,c.gratuity,c.grossSalary,c.netSalary\r\n"+
				"from associate a inner join bankdetails b inner join salary c\r\n"+
					"on a.associateId=b.associateId and a.associateId=c.associateId\r\n"+
						"where a.associateId=?"; 
		
		Associate associate = (Associate)jdbcTemplate.queryForObject(str, new Object[] { associateId }, new AssociateMapper());
		System.out.println(associate);
		return associate;
	}

	@Override
	public List<Associate> getAssociates() {
		
		return null;
	}

	@Override
	public int save(Associate associate) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}

