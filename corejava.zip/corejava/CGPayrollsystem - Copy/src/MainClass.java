package com.cg.payroll.main;
public class MainClass {

	public static void main(String[] args) {
		Associate associate1 = new Associate();
		associate1.setAssociateId(12345);
		System.out.println(associate1.getAssociateId()); 

}
	}

	
	

}
