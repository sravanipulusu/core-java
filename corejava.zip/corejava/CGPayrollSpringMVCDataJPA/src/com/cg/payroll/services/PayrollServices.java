package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.PayrollServicesDownException;

public interface PayrollServices {

	int acceptAssociateDetails(Associate associate) throws PayrollServicesDownException ;

	float calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException;

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException, PayrollServicesDownException;

	boolean deleteAssociate(int associateId) throws AssociateDetailsNotFoundException, PayrollServicesDownException ;
	
	Boolean  updateAssociateDetails(int associateId,String firstName, String lastName, String department, String emailId,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) throws AssociateDetailsNotFoundException, PayrollServicesDownException ;
	
	List<Associate> getAssociateDetails();

	int acceptAssociateDetails(String firstName, String lastName, String department, String emailId, String designation,
			String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf, int accountNumber,
			String bankName, String ifscCode) throws PayrollServicesDownException;

}