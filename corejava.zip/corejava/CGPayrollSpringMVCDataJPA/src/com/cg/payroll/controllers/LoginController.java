package com.cg.payroll.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;


	@Controller
	public class LoginController {
		@Autowired
		PayrollServices payrollServices;
		@RequestMapping(value="/loginUser")
		public String loginUser(@ModelAttribute("associate")Associate associate) throws AssociateDetailsNotFoundException, PayrollServicesDownException{
			System.out.println(associate);
			System.out.println(payrollServices.getAssociateDetails(associate.getAssociateId()).getPassword());
			if(associate.getPassword().equals(payrollServices.getAssociateDetails(associate.getAssociateId()).getPassword())) {
				return "successPage";
			}
			return "errorPage";
		
		}
		
	}

