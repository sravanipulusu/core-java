package com.cg.payroll.daoservices;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.omg.CORBA.OBJ_ADAPTER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.utility.AssociateMapper;
import com.cg.payroll.utility.PayrollUtility;
import java.sql.PreparedStatement;
@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices{
	@Autowired(required=true)
	private EntityManagerFactory entityManagerFactory;
	
	@Override
	public int insertAssociate(Associate associate)  {
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	entityManager.getTransaction().begin();
	entityManager.persist(associate);
	entityManager.flush();
	entityManager.getTransaction().commit();
	entityManager.close();
		return associate.getAssociateId();
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public boolean deleteAssociate(int associateId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.remove(entityManager.find(Associate.class, associateId));
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Associate getAssociate(int associateId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return entityManager.find(Associate.class, associateId);
		
	}

	@Override
	public List<Associate> getAssociates() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query=entityManager.createQuery("from Associate a",Associate.class);
				
		return query.getResultList();
		
	}

	@Override
	public int save(Associate associate) {
		// TODO Auto-generated method stub
		return 0;
	}
}
