package com.cg.banking.daoservices;
import com.cg.banking.services.*;
import com.cg.banking.utility.BankingUtility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices{
	Random rand = new Random();
	public static HashMap<Integer, Customer> customerList=new HashMap<>();
//	private static int CUSTOMER_ID_COUNTER=10;
	//private static int CUSTOMER_IDX_COUNTER=0;
	//private static int ACCCOUNT_ID_COUNTER = 1234;
	//private static int TRANSACTION_ID_COUNTER=1111;
	 public int insertCustomer(Customer customer) {	
		 
		 customerList.put(BankingUtility.CUSTOMER_ID_COUNTER, customer);
		 customer.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		 return customer.getCustomerId();
	}
	 
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(BankingUtility.ACCCOUNT_ID_COUNTER++);
		customerList.get(customerId).getAccountList().put(account.getAccountNo(), account);
		account.setStatus("Active");
		return account.getAccountNo();
	}


	public boolean updateAccount(int customerId, Account account) {
		customerList.get(customerId).getAccountList().put(account.getAccountNo(), account);
		return true;
	}


	public int generatePin(int customerId, Account account) {
		long accountNo = account.getAccountNo();
		getAccount(customerId, accountNo).setPinNumber(rand.nextInt(9000)+1000);
		return getAccount(customerId, accountNo).getPinNumber();
	}

	
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		transaction.setTransactionId(BankingUtility.TRANSACTION_ID_COUNTER++);
		getAccount(customerId, accountNo).getTransactionList().put(BankingUtility.TRANSACTION_ID_COUNTER, transaction);
		return true;
		}
			
	public boolean deleteCustomer(int customerId) {
		Customer c=customerList.remove(customerId);
		if(c==null) return false;
				return true;
			}
	
	
	public boolean deleteAccount(int customerId, long accountNo) {
		Account a =getCustomer(customerId).getAccountList().remove(accountNo);
			if(a==null) return false;
					return true;				
		}		
	

	public Customer getCustomer(int customerId) {
		
     return customerList.get(customerId);
	}


	public Account getAccount(int customerId, long accountNo) {
		
				return getCustomer(customerId).getAccountList().get(accountNo);
		
	}

	
	public List<Customer> getCustomers() {
		List<Customer> list = new ArrayList<>(customerList.values());
		return list;
	}

	
	public List<Account> getAccounts(int customerId) {
		return  new ArrayList<>(customerList.get(customerId).getAccountList().values());
	}

	
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		
		return  new ArrayList<>(customerList.get(customerId).getAccountList().get(accountNo).getTransactionList().values());
	}

	public int hashCode() {
		
		return super.hashCode();
	}

	
	public boolean equals(Object obj) {
	
		return super.equals(obj);
	}

	
	protected Object clone() throws CloneNotSupportedException {
		
		return super.clone();
	}


	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}
	

}
