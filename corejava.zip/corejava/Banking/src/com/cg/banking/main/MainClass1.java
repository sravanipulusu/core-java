package com.cg.banking.main;
import java.util.Scanner;
import com.cg.banking.exceptions.*;
import com.cg.banking.beans.*;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
public class MainClass1 {
	public static void main(String[] args) {
		BankingServicesImpl bankservices=new BankingServicesImpl();
		Scanner a=new Scanner(System.in);
		int k=0;
		while (k!=16) {
			try{
				System.out.println("Select the Input\n"+"1)Register Customer\n2)Add Account\n3)Generate Pin\n4)Change Pin\n"
						+"5)Deposit Amount\n6)Withdraw Amount\n7)Fund Transfer\n8)Customer Details\n9)Account Details\n10)Close Account\n"
						+"11)Remove Customer\n12)Get all customer Details\n13)Get all account Details\n14)Get all Transaction Details\n15)Get Account status\n16)Exit Portal");
			k=a.nextInt();
			switch (k) {
			case 1:System.out.println("Enter Customer Details :");
			System.out.println("Enter First name");
			String firstName=a.next();
			System.out.println("Enter Last name");
			String lastName=a.next();
			System.out.println("Enter EmailId");
			String customerEmailId=a.next();
			System.out.println("Enter PAN card number");
			String panCard=a.next();
			System.out.println("Enter Local Address City");
			String localAddressCity=a.next();
			System.out.println("Enter Local Address state");
			String localAddressState=a.next();
			System.out.println("Enter Local Address pincode");
			int localAddressPinCode=a.nextInt();
			System.out.println("Enter Home Address City");
			String homeAddressCity=a.next();
			System.out.println("Enter Home Address State");
			String homeAddressState=a.next();
			System.out.println("Enter Home Address PinCode");
			int homeAddressPinCode=a.nextInt();
			int cusid=bankservices.acceptCustomerDetails(firstName, lastName, customerEmailId, panCard, localAddressCity, localAddressState, localAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
			System.out.println("Succesfully created customer with Id \n"+cusid);
			System.out.println((bankservices.getCustomerDetails(cusid)).toString());
			break;
			case 2:System.out.println("Enter Account details");
			System.out.println("Enter the customer Id");
			int customerId=a.nextInt();
			System.out.println("Enter Account Type");
			String accountType=a.next();
			System.out.println("Enter Initial Balance");
			float initBalance=a.nextFloat();
			long acno=bankservices.openAccount(customerId, accountType, initBalance);
			System.out.println("successfully added account "+acno+" for customer of id "+customerId+"\n");
			break;
			case 3:System.out.println("Enter the details to generate a PIN");
			System.out.println("Enter CustomerId");
			int customerId1=a.nextInt();
			System.out.println("EnterAccountNo");
			long accountNo=a.nextLong();
			int pin=bankservices.generateNewPin(customerId1,accountNo);
			System.out.println("The generated Pin is"+pin);
			break;
			case 4:System.out.println("Enter the details for pin change\n"+"customerId, AccountNo,OldPin,NewPin");
			boolean flag=bankservices.changeAccountPin(a.nextInt(), a.nextLong(), a.nextInt(), a.nextInt());
			if(flag==true) System.out.println("Successfully pin changed");
			else System.out.println("Pin change failed ,Give vaild details");
			break;
			case 5:System.out.println("Enter the details to deposit :");
			System.out.println("Enter customerId");
			int customerId2=a.nextInt();
			System.out.println("EnterAccountNo");
			long accountNo1=a.nextLong();
			System.out.println("Enter the amount");
			int amount=a.nextInt();
			float balance=bankservices.depositAmount(customerId2, accountNo1, amount);
			System.out.println("Balance Amount : "+balance);
			break;
			case 6:System.out.println("Enter the details to withdraw :");
			System.out.println("Enter customerId");
			int customerId3=a.nextInt();
			System.out.println("EnterAccountNo");
			long accountNo2=a.nextLong();
			System.out.println("Enter the amount");
			int amount1=a.nextInt();
			System.out.println("Enter the pin number");
			int pin1=a.nextInt();
			float bal=bankservices.withdrawAmount(customerId3, accountNo2, amount1, pin1);
			System.out.println("Balance Amount : "+bal);
			break;
			
			case 7:System.out.println("Enter the details for fund transfer :");
			System.out.println("Enter customerId of receiver ");
			int cusIdTo=a.nextInt();
			System.out.println("Enter customerId of sender ");
			int cusIdFrom=a.nextInt();
			System.out.println("Enter account number of receiver ");
			long accountNumberTo=a.nextLong();
			System.out.println("Enter account number of sender ");
			long accountNumberFrom=a.nextLong();
			System.out.println("Enter the amount to be transfered");
			int amount2=a.nextInt();
			System.out.println("Enter the pin number");
			int pin2=a.nextInt();
			boolean b=bankservices.fundTransfer(cusIdTo, accountNumberTo, cusIdFrom, accountNumberFrom, amount2, pin2);
			if(b==true) System.out.println("Fund Transfer successfull");
			else System.out.println("Fund Transfer failed");
			break;
			case 8: System.out.println("Enter customerId to get customer details");
			int customerId4=a.nextInt();
			System.out.println(bankservices.getCustomerDetails(customerId4));
			break;
			case 9: System.out.println("Enter customerId to get account details");
			int customerId5=a.nextInt();
			System.out.println("Enter account number to get account details");
			long accountNo3=a.nextLong();
			System.out.println(bankservices.getAccountDetails(customerId5, accountNo3));
			break;
			case 10:System.out.println("Enter customerId and account number to close the account");
			boolean c=bankservices.closeAccount(a.nextInt(), a.nextLong());
			if(c==true) System.out.println("Account is closed");
			else System.out.println("Account close failed");
			break;
			case 11:System.out.println("Enter customerId to remove customer");
			int customerId6=a.nextInt();
			boolean d=bankservices.removeCustomer(customerId6);
			if(d==true) System.out.println("Customer is removed");
			else System.out.println("customer removal failed");
			break;
			case 12:System.out.println("Get all customer details");
			System.out.println(bankservices.getAllCustomerDetails());
			break;
			case 13:System.out.println("Enter the customerId to get all account details");
			int customerId7=a.nextInt();
			System.out.println(bankservices.getcustomerAllAccountDetails(customerId7));
			break;
			case 14:System.out.println("Enter the customerId and account number to get all transaction details");
			System.out.println(bankservices.getAccountAllTransaction(a.nextInt(), a.nextLong()));
			break;
			case 15:System.out.println("Enter the customerId and account number to get account status");
			System.out.println(bankservices.accountStatus(a.nextInt(), a.nextLong()));
			break;
			default:
				break;
		
			}
		
		}
			catch(AccountBlockedException e){
				e.printStackTrace();
			}
			catch(AccountNotFoundException e){
				e.printStackTrace();
			}
			catch (BankingServicesDownException e) {
				e.printStackTrace();
			}
			catch (CustomerNotFoundException e) {
				e.printStackTrace();
			}
			catch (InsufficientAmountException e) {
				e.printStackTrace();
			}
			catch (InvalidAccountTypeException e) {
				e.printStackTrace();
			}
			catch (InvalidAmountException e) {
				e.printStackTrace();
			}
			catch (InvalidPinNumberException e) {
				e.printStackTrace();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}

		/*
		int cust=bankServices.acceptCustomerDetails("sravani", "pulusu", "email", "g55g6", "hyd", "Tg", 500072, "hyd", "Tg", 500072);
		System.out.println(cust);
		long acc=bankServices.openAccount(cust, "savings", 10000);
		//long acc1=bankServices.openAccount(cust, "savings", 300000);
		long acc2=bankServices.openAccount(cust, "savings",4300000);
		System.out.println(acc2);
		int pin=bankServices.generateNewPin(cust, acc);
		float bal=bankServices.depositAmount(cust, acc, 10000);
		float wit=bankServices.withdrawAmount(cust, acc, 15000,pin);
		boolean i=bankServices.changeAccountPin(cust, acc, pin, 1100);
		System.out.println((bankServices.getCustomerDetails(cust)).toString());
		System.out.println("pin"+" "+pin+" "+"Balance "+" "+bal+" "+"balance after withdrawl "+" "+wit+" "+i);*/
	}
		

}

