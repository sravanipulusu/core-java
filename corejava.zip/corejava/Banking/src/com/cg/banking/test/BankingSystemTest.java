package com.cg.banking.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utility.BankingUtility;

public class BankingSystemTest {
		private static BankingServices bankingservices;

		@BeforeClass
		public static void setUpBeforeClass() {
			bankingservices=new BankingServicesImpl();
		}
		
		@Before
		public void setUpMockData() {
			Customer customer1 = new Customer("sdsd54", "sravani", "pulusu", "sravani@gmail.com", new Address("guntur", "andhra", 522426), new Address("pune", "maharashtra", 500043));
			customer1.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		
			Account account1 = new Account("savings", 50000);
			account1.setAccountNo(BankingUtility.ACCCOUNT_ID_COUNTER++);
			account1.setStatus("Active");
			account1.setPinNumber(1245);
		
			
			Transaction transaction1 = new Transaction( 5000, "deposit");
			transaction1.setTransactionId(BankingUtility.TRANSACTION_ID_COUNTER++);

			BankingDAOServicesImpl.customerList.put(customer1.getCustomerId(),customer1);
			BankingDAOServicesImpl.customerList.get(customer1.getCustomerId()).accountList.put(account1.getAccountNo(), account1) ;      
			BankingDAOServicesImpl.customerList.get(customer1.getCustomerId()).accountList.get(account1.getAccountNo()).transactionList.put(transaction1.getTransactionId(), transaction1) ;
				
			
			Customer customer2 = new Customer("sdsd54", "ravi", "pulusu", "ravi@gmail.com", new Address("macherla", "andhra", 522426), new Address("pune", "maharashtra", 500043));
			customer2.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
			Account account2 = new Account("savings", 30000);
			account2.setAccountNo(BankingUtility.ACCCOUNT_ID_COUNTER++);
			account2.setStatus("Active");
			account2.setPinNumber(1246);
			Transaction transaction2 = new Transaction( 6500, "deposit");
			transaction2.setTransactionId(BankingUtility.TRANSACTION_ID_COUNTER++);
		
			BankingDAOServicesImpl.customerList.put(customer2.getCustomerId(),customer2);
			BankingDAOServicesImpl.customerList.get(customer2.getCustomerId()).accountList.put(account2.getAccountNo(), account2) ;      
			BankingDAOServicesImpl.customerList.get(customer2.getCustomerId()).accountList.get(account2.getAccountNo()).transactionList.put(transaction2.getTransactionId(), transaction2) ;
				
		}
		
		@Test
		public void  testForAcceptCustomerDetailsforValidCustomerId() throws CustomerNotFoundException, BankingServicesDownException{
			assertEquals(102, bankingservices.acceptCustomerDetails("srava", "pulusu", "srsvcxvd", "jgyu78", "dsds", "ytyty", 89899, "ryyyy", "iiiii", 65858));
		}
		
		
		@Test(expected=CustomerNotFoundException.class)
		public void testForAcceptCustomerDetailsforInValidCustomerId() throws CustomerNotFoundException{
			bankingservices.getCustomerDetails(20);
		}
		
		@Test
		public void testForOpenAccountforvalidCustomerId() throws CustomerNotFoundException, AccountNotFoundException, InvalidAmountException, InvalidAccountTypeException{
			assertEquals(1236, bankingservices.openAccount(100, "savings", 2000));
		}
		
		@Test(expected=CustomerNotFoundException.class)
		public void testForOpenAccountforInvalidCustomerId() throws AccountNotFoundException, CustomerNotFoundException, BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException{
			bankingservices.openAccount(20, "salary",2000);
		}
		@Test(expected=InvalidAccountTypeException.class)
		public void testForOpenAccountforInvalidAccountType() throws AccountNotFoundException, InvalidAmountException, InvalidAccountTypeException, CustomerNotFoundException{
			bankingservices.openAccount(100, "dsdsd",2300);
		}
		@Test
		public void  testForOpenAccountforvalidAccountType() throws InvalidAccountTypeException, AccountNotFoundException, InvalidAmountException, CustomerNotFoundException, BankingServicesDownException{
			assertEquals("savings", bankingservices.getAccountDetails(101, 1235).getAccountType());
		}
		@Test(expected=InvalidAmountException.class)
		public void testForOpenAccountforInvalidAmount() throws InvalidAmountException, AccountNotFoundException, InvalidAccountTypeException, CustomerNotFoundException{
			bankingservices.openAccount(100, "savings", -20);
		}
		@Test
		public void testForOpenAccountforValidAmount() throws InvalidAmountException, CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
			assertEquals(50000,bankingservices.getAccountDetails(100, 1234).getAccountBalance(),0);	
		}
		@Test(expected=CustomerNotFoundException.class)
		public void testForDepositAmountforInvalidcustomerId() throws CustomerNotFoundException, InvalidAmountException, AccountBlockedException, InvalidAccountTypeException, AccountNotFoundException{
			bankingservices.depositAmount(200, 1234, 5000);
		}
		@Test
		public void testForDepositAmountforvalidcustomerId() throws CustomerNotFoundException, InvalidAmountException, AccountBlockedException, InvalidAccountTypeException, AccountNotFoundException{
				assertEquals(33000, bankingservices.depositAmount(101, 1235, 3000),0);
		}
		@Test(expected=AccountNotFoundException.class)
		public void testForDepositAmountforInvalidAccount() throws AccountNotFoundException, InvalidAmountException, CustomerNotFoundException, AccountBlockedException, InvalidAccountTypeException{
			bankingservices.depositAmount(100, 2222, 50000);
		}
		@Test
		public void testForDepositAmountforValidAccount() throws AccountNotFoundException, InvalidAmountException, CustomerNotFoundException, AccountBlockedException, InvalidAccountTypeException, BankingServicesDownException{
			assertEquals(1234, bankingservices.getAccountDetails(100, 1234).getAccountNo(),0);
		}
		@Test(expected=InvalidAmountException.class)
		public void testForDepositAmountforInValidAmount() throws InvalidAmountException, CustomerNotFoundException, AccountBlockedException, InvalidAccountTypeException, AccountNotFoundException{
			bankingservices.depositAmount(100, 1234, -63);
		}
		@Test
		public void testForWithdrawAmountforValidAccountBalance() throws AccountNotFoundException, InvalidAccountTypeException, InvalidPinNumberException, InvalidAmountException, InsufficientAmountException, CustomerNotFoundException, AccountBlockedException{
			assertEquals(45000, bankingservices.withdrawAmount(100, 1234, 5000, 1245),0);
		}
		@Test(expected=AccountNotFoundException.class)
		public void testForWithdrawAmountforInValidAccount() throws AccountNotFoundException, InvalidAccountTypeException, InvalidPinNumberException, InvalidAmountException, InsufficientAmountException, CustomerNotFoundException, AccountBlockedException{
			bankingservices.withdrawAmount(100, 3232, 45000, 1245);
		}
		@Test(expected=CustomerNotFoundException.class)
		public void testForWithdrawAmountforInValidCustomer() throws CustomerNotFoundException, InvalidAccountTypeException, InvalidPinNumberException, InvalidAmountException, InsufficientAmountException, AccountNotFoundException, AccountBlockedException{
			bankingservices.withdrawAmount(212, 323, 2356, 1245);
		}
		@Test(expected=InsufficientAmountException.class)
		public void testForWithdrawAmountforInValidAmount() throws InvalidAmountException, InvalidAccountTypeException, InvalidPinNumberException, InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
			bankingservices.withdrawAmount(100, 1234, 50051, 1245);
		}
		@Test(expected=InvalidPinNumberException.class)
		public void testForWithdrawAmountforInValidpin() throws InvalidAmountException, InvalidAccountTypeException, InvalidPinNumberException, InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
			bankingservices.withdrawAmount(100, 1234, 5000, 1248);
		}
		@Test
		public void testForFundTransferforValidCustomer() throws CustomerNotFoundException, InvalidAccountTypeException, InvalidPinNumberException, InvalidAmountException, InsufficientAmountException, AccountNotFoundException, AccountBlockedException{
			assertTrue(bankingservices.fundTransfer(101, 1235, 100, 1234, 500, 1245));
		}
		@Test(expected=CustomerNotFoundException.class)
		public void testForFundTransferforInValidCustomer() throws CustomerNotFoundException, InvalidAccountTypeException, InvalidPinNumberException, InvalidAmountException, InsufficientAmountException, AccountNotFoundException, AccountBlockedException{
				bankingservices.fundTransfer(211, 1234, 108, 1234, 665, 1245);
		}
		@Test(expected=InvalidAmountException.class)
		public void testForFundTransferforInValidAmount() throws CustomerNotFoundException, InvalidAccountTypeException, InvalidPinNumberException, InvalidAmountException, InsufficientAmountException, AccountNotFoundException, AccountBlockedException{
				bankingservices.fundTransfer(211, 1238, 101, 1234, -6065, 1245);
		}
		@Test
		public void testForGetCustomerDetailsforValidCustomer() throws CustomerNotFoundException{
		assertEquals(101,bankingservices.getCustomerDetails(101));
		}
		@Test(expected=CustomerNotFoundException.class)
		public void testForGetCustomerDetailsforInValidCustomer() throws CustomerNotFoundException{
			bankingservices.getCustomerDetails(125);
		}
		@Test
		public void testForGetAccountDetailsforValidCustomer() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
				
			Transaction transaction2 = new Transaction( 6500, "deposit");
			transaction2.setTransactionId(1112);
			HashMap<Integer,Transaction> transactionList = new HashMap<>();
			
			Account account=new Account(1235, 1246, 0, 30000, "savings", "Active", transactionList);
			account.transactionList.put(1112, transaction2);
		
		assertEquals(account,bankingservices.getAccountDetails(101, 1235));
		}
		
		@Test
		public void testForAccountStatusForValidCustomer() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
			assertEquals("Active", bankingservices.getAccountDetails(101, 1235).getStatus());
		}
		@Test(expected=CustomerNotFoundException.class)
		public void testForAccountStatusForInValidCustomer() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
			bankingservices.getAccountDetails(130, 1235).getStatus();
		}
		@Test(expected=AccountNotFoundException.class)
		public void testForAccountStatusForInValidAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
			bankingservices.getAccountDetails(100,0).getStatus();
		}
		@Test
		public void testForCloseAccountforValidCustomer() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
			Transaction transaction2 = new Transaction( 6500, "deposit");
			transaction2.setTransactionId(1112);
			HashMap<Integer,Transaction> transactionList = new HashMap<>();
			
			Account account=new Account(1235, 1246, 0, 30000, "savings", "Active", transactionList);
			account.transactionList.put(1112, transaction2);
		
			assertEquals(account, bankingservices.getAccountDetails(101, 1235));	
		}
		
		@AfterClass
		public static void tearDownTestEnv() {
			bankingservices=null;
		}
		
		@After
		public void tearDownMockData() {
			
		BankingDAOServicesImpl.customerList.clear();
			BankingUtility.CUSTOMER_ID_COUNTER=100;
			BankingUtility.ACCCOUNT_ID_COUNTER=1234;
			BankingUtility.TRANSACTION_ID_COUNTER=1111;
		}
	}


