package com.cg.banking.utility;

public class BankingUtility {
	public static int  ACCCOUNT_ID_COUNTER = 1234, CUSTOMER_ID_COUNTER=100,TRANSACTION_ID_COUNTER=1111;

}
