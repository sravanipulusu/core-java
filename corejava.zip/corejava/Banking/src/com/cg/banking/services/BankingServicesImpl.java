package com.cg.banking.services;
import java.util.List;

import javax.security.auth.login.AccountLockedException;

import com.cg.banking.beans.*;
import com.cg.banking.daoservices.*;
import com.cg.banking.exceptions.*;

public class BankingServicesImpl implements BankingServices{
	private BankingDAOServices daoservices;
	public BankingServicesImpl() {
		daoservices = new BankingDAOServicesImpl();
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String customerEmailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
	

		return daoservices.insertCustomer(new Customer(firstName, lastName, customerEmailId,panCard, new Address(localAddressCity,localAddressState, localAddressPinCode),new Address(homeAddressCity,homeAddressState,homeAddressPinCode)));
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws AccountNotFoundException,InvalidAccountTypeException,InvalidAmountException,CustomerNotFoundException{
	if(initBalance<0)
			throw new InvalidAmountException("enter valid amound");
	if(daoservices.getCustomer(customerId)==null)
		throw new CustomerNotFoundException("customer not found");
	if(accountType.equalsIgnoreCase("salary")||accountType.equalsIgnoreCase("savings")||accountType.equalsIgnoreCase("current"))
	return daoservices.insertAccount(customerId, new Account(accountType, initBalance));
	else throw new InvalidAccountTypeException("invalid account type");
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws InvalidAmountException,CustomerNotFoundException,
	AccountBlockedException,InvalidAccountTypeException,AccountNotFoundException {
		if(daoservices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("account not found");
		if(daoservices.getAccount(customerId, accountNo).getStatus()!="Active")
			throw new AccountBlockedException("Account is blocked");
		if(amount<0) throw new InvalidAmountException("Invalid amount");
		
		float totalbal=daoservices.getAccount(customerId, accountNo).getAccountBalance()+amount;
		daoservices.getAccount(customerId, accountNo).setAccountBalance(totalbal);
		daoservices.insertTransaction(customerId, accountNo, new Transaction(amount, "deposit"));
		return daoservices.getAccount(customerId, accountNo).getAccountBalance();
	
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber) throws InvalidAccountTypeException,InvalidPinNumberException,
	CustomerNotFoundException,AccountNotFoundException,InvalidAmountException,InsufficientAmountException,AccountBlockedException{	
		if(daoservices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account not found");
		if(daoservices.getAccount(customerId, accountNo).getAccountBalance()<amount)
			throw new InsufficientAmountException("Insufficient Balance");
		while(daoservices.getAccount(customerId, accountNo).getPinCounter()<=3&&daoservices.getAccount(customerId, accountNo).getPinNumber()!=pinNumber){
			if(daoservices.getAccount(customerId, accountNo).getPinNumber()!=pinNumber){
				daoservices.getAccount(customerId, accountNo).setPinCounter(daoservices.getAccount(customerId, accountNo).getPinCounter()+1);
				System.out.println(daoservices.getAccount(customerId, accountNo).getPinCounter());
				throw new InvalidPinNumberException("Invalid Pin");
			}
		}
		if(daoservices.getAccount(customerId, accountNo).getPinCounter()>3){  
			daoservices.getAccount(customerId, accountNo).setStatus("Blocked");
			throw new AccountBlockedException("Account is blocked");
		}
		if(!daoservices.getAccount(customerId, accountNo).getStatus().equals("Active"))
			throw new AccountBlockedException("Account is blocked");
		float finalamt=daoservices.getAccount(customerId, accountNo).getAccountBalance()-amount;
		if(daoservices.getAccount(customerId, accountNo).getPinNumber()==pinNumber) {
		daoservices.getAccount(customerId, accountNo).setAccountBalance(finalamt);
		daoservices.insertTransaction(customerId, accountNo, new Transaction(amount,"withdraw"));
		return daoservices.getAccount(customerId, accountNo).getAccountBalance();
	
	}
	return -1;
}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InvalidAccountTypeException, InvalidPinNumberException,
	InvalidAmountException, InsufficientAmountException,AccountNotFoundException, CustomerNotFoundException, AccountBlockedException {
		if(transferAmount<0) throw new InvalidAmountException("Invalid amount");
		
		withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
		depositAmount(customerIdTo, accountNoTo, transferAmount);
		return true;
	
	}

	@Override
	public Customer getCustomerDetails (int customerId) throws CustomerNotFoundException {
		if(daoservices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		
		return daoservices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo) throws CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException{
	if(daoservices.getCustomer(customerId)==null)
		throw new CustomerNotFoundException("customer not found");
	if(daoservices.getAccount(customerId, accountNo)==null)
		throw new AccountNotFoundException("account not found");
		return daoservices.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo) throws CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException{
		System.out.println(customerId + " " + accountNo);
		if(daoservices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("account not found");
		return daoservices.generatePin(customerId, getAccountDetails(customerId, accountNo));
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber) throws CustomerNotFoundException,AccountNotFoundException,InvalidPinNumberException,BankingServicesDownException{
		if(daoservices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("account not found");
		daoservices.getAccount(customerId, accountNo).setPinNumber(newPinNumber);
		daoservices.getAccount(customerId, accountNo).setStatus("Active");
		return true;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException {
		
		return daoservices.getCustomers();
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId) throws BankingServicesDownException,CustomerNotFoundException {
		if(daoservices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		return daoservices.getAccounts(customerId);
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo) throws BankingServicesDownException,CustomerNotFoundException,AccountNotFoundException {
		if(daoservices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("account not found");
		return daoservices.getTransactions(customerId, accountNo);
	}

	@Override
	public String accountStatus(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,AccountNotFoundException, AccountBlockedException
 {
		if(daoservices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("account not found");
		return daoservices.getAccount(customerId, accountNo).getStatus();
	}
	
	public boolean closeAccount(int customerId, long accountNo)throws BankingServicesDownException,
	CustomerNotFoundException,AccountNotFoundException {
		if(daoservices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("customer not found");
		if(daoservices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("account not found");
		return daoservices.deleteAccount(customerId, accountNo);
	}
	
	public boolean removeCustomer(int customerId) throws BankingServicesDownException,CustomerNotFoundException {
	if(daoservices.getCustomer(customerId)==null)
		throw new CustomerNotFoundException("customer not found");
	
		return daoservices.deleteCustomer(customerId);
	}
}

