package com.cg.stat.main;

public class MainClass {

}
