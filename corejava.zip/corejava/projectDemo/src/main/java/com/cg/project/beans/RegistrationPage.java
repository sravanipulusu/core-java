
package com.cg.project.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RegistrationPage {
	@FindBy(id="user_login")
	WebElement userName;
	
	@FindBy(id="user_email")
	WebElement email;
	
	@FindBy(id="user_password")
	WebElement password;
	
	@FindBy(className="btn")
	WebElement button;
	
	public RegistrationPage(){}

	public RegistrationPage(WebElement userName, WebElement email, WebElement password, WebElement button) {
		super();
		this.userName = userName;
		this.email = email;
		this.password = password;
		this.button = button;
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName); 
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getButton() {
		return button;
	}

	public void clickSubmitButton() {
		button.submit();
	}
	
	
	
}

