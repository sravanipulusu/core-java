package com.cg.projectDemo;
import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.LoginPage;

public class LoginPageTest {

	static WebDriver driver;
	private LoginPage loginPage;

	@BeforeClass
	public static void setUpDriverEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");	
		driver= new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Before
	public void setUptestEnv() {
		driver.get("https://github.com/login");
		loginPage=new LoginPage();
		PageFactory.initElements(driver, loginPage);
	}

	@Test
	public void testForBlankUserNameAndPassword() {
		loginPage.setUserName("");
		loginPage.setPassword("");
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="Incorrect username or password.";
		assertEquals(actualErrorMessage, message);

	}

	@Test
	public void testForInValidUserNameAndValidPassword() {
		loginPage.setUserName(getInvalidUserName());
		loginPage.setPassword(getValidPassword());
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="Incorrect username or password.";
		assertEquals(actualErrorMessage, message);
	}

	private String getValidPassword() {
		
		return "";
	}

	private String getInvalidUserName() {
		
		return "sravani";
	}

	@Test
	public void testForValidUserNameAndInValidPassword() {
		loginPage.setUserName(getValidUserName());
		loginPage.setPassword(getInvalidPassword());
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="Incorrect username or password.";
		assertEquals(actualErrorMessage, message);

	}

	private String getInvalidPassword() {
		
		return "xyz";
	}

	private String getValidUserName() {
	
		return "pulusu";
	}

	@Test
	public void testForInValidUserNameAndPassword() {
		loginPage.setUserName(getInvalidUserName());
		loginPage.setPassword(getInvalidPassword());
		loginPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath("//div[@class='container']")).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="Incorrect username or password.";
		assertEquals(actualErrorMessage, message);
	}

	@Test
	public void testForValidUserNameAndPassword() {
		loginPage.setUserName(getValidUserName());
		loginPage.setPassword(getValidPassword());
		loginPage.clickSubmitButton();
	}

	@After
	public void tearDowntestEnv() {
		loginPage=null;
	}

	@AfterClass
	public static void tearDownDriverEnv() {
		driver.close();
		driver=null;

	}
}

