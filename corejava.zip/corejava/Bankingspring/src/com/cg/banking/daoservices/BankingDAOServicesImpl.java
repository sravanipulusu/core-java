package com.cg.banking.daoservices;
import com.cg.banking.services.*;
import com.cg.banking.utility.BankingUtility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
@Component(value="BankingDAOServices")
public class BankingDAOServicesImpl implements BankingDAOServices{
	@Autowired
	private SessionFactory sessionFactory;
	private org.hibernate.Transaction tx;
	private Session session;
 public BankingDAOServicesImpl() {
		
	}
	@Override
	public int insertCustomer(Customer customer) {
		try{
		session	=sessionFactory.openSession();
		tx= session.beginTransaction();
		int custId=(int) session.save(customer);
		tx.commit();
		return custId;
		}
		catch(HibernateException e){
			e.printStackTrace();
			tx.rollback();
			throw e;
		}
		finally{
			session.close();
		}
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}
	}