package com.cg.payroll.test;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;
public class PayrollServicesTest {

private static PayrollServices payrollservices;
	
	@BeforeClass
		public static void setUpBeforeClass(){
			payrollservices=new PayrollServicesImpl();
	}

	@Before
		public void setUpMockData() {
		//PayrollUtility.ASSOCIATE_ID_COUNTER=111;
		Associate associate1= new Associate( PayrollUtility.ASSOCIATE_ID_COUNTER++,150000, "SRAVANI","pulusu", "java", "btech", "dfdfdfd", "sdfsf@gdfg",new salary(30000, 1000, 1000), new BankDetails(54564546, "citi", "citi000076"));
	    Associate associate2= new Associate( PayrollUtility.ASSOCIATE_ID_COUNTER++,150000, "prabha","buduri", "sap", "btech", "dfdfdfd", "sdfsf@gdfg", new salary(30000, 1000, 1000),new BankDetails(50064546, "citi", "citi000076"));
	    Associate associate3= new Associate( PayrollUtility.ASSOCIATE_ID_COUNTER++,15000, "bhargav","kommireddy", "java", "btech", "dfdfdfd", "sdfsf@gdfg", new salary(50000, 1000, 1000) ,new BankDetails(54564546, "citi", "citi000076"));
	    PayrollDAOServicesImpl.associateList.put(associate1.getAssociateId(), associate1);
	    PayrollDAOServicesImpl.associateList.put(associate2.getAssociateId(), associate2);
	    PayrollDAOServicesImpl.associateList.put(associate3.getAssociateId(), associate3);
	    
	}
	@Test
	public void testForAcceptAssociateDetailsForValidAssociateId() throws AssociateDetailsNotFoundException{
		int expectedAssociateId=114;
		int actualAssociateId=payrollservices.acceptAssociateDetails(15000, "ravi", "pulusu", "java", "btech", "fdfdfd", "ravi@gmail", 65656565, "hdfc", "hdfc5656", 250000, 1000, 1000);
		assertEquals(expectedAssociateId, actualAssociateId);
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testForgetAssociateDetailsForInValidAssociateId() throws AssociateDetailsNotFoundException{
		assertEquals(new Associate(113, 15000, "bhargav","kommireddy", "java", "btech", "dfdfdfd", "sdfsf@gdfg", new salary(50000, 1000, 1000) ,new BankDetails(54564546, "citi", "citi000076")),payrollservices.getAssociateDetails(123));
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testForDeleteAssociateforInvalidAssociateId() throws AssociateDetailsNotFoundException{
			payrollservices.getAssociateDetails(526);
		}
	@Test
	public void testForDeleteAssociateforvalidAssociateId() throws AssociateDetailsNotFoundException{
			assertTrue(payrollservices.deleteAssociate(112));
		}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testForCalculateNetSalaryforInvalidAssociateId() throws AssociateDetailsNotFoundException{
		assertNotEquals(5454,payrollservices.calculateNetSalary(252));
	}
	@Test
	public void testForCalculateNetSalaryforvalidAssociateId() throws AssociateDetailsNotFoundException{
		assertEquals(50700, payrollservices.calculateNetSalary(111), 0);
	}
	
	@After
	public void tearDownMockData()
	{
		PayrollDAOServicesImpl.associateList.clear();
	PayrollUtility.ASSOCIATE_ID_COUNTER=111;
	//PayrollDAOServicesImpl.associateList.clear();
	}
	@AfterClass
	public static void tearDownTestEnv() {
		payrollservices = null;
	}

}
