package com.cg.mobilebilling.main;
import com.cg.mobilebilling.beans.*;

public class MainClass2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
			Account account1 = new Account();
			account1.setMobileNo(900000);
			System.out.println(account1.getMobileNo());
			Customer customer1 = new Customer(45450, 99598980, 3234323, 250595, "sravani" , "pulusu" , "sravani@gmail.com" , "i343hgf");
			System.out.println(customer1.getCustomerId());
			System.out.println(customer1.getMobileNo());
			System.out.println(customer1.getAdharNo());
			System.out.println(customer1.getDateOfBirth());
			System.out.println(customer1.getFirstName());
			System.out.println(customer1.getLastName());
			System.out.println(customer1.getEmailId());
			System.out.println(customer1.getPancardNo());
			
			
	}

}
