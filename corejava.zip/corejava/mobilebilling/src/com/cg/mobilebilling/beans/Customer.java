package com.cg.mobilebilling.beans;

public class Customer {
		private int customerId,mobileNo,adharNo,dateOfBirth;
		private String firstName,lastName,emailId,pancardNo;
		private Address address;
		private Account[] account;
		
		public Customer() {}

		public Customer(int customerId, int mobileNo, int adharNo, int dateOfBirth, String firstName, String lastName,
				String emailId, String pancardNo, Address address, Account[] account) {
			super();
			this.customerId = customerId;
			this.mobileNo = mobileNo;
			this.adharNo = adharNo;
			this.dateOfBirth = dateOfBirth;
			this.firstName = firstName;
			this.lastName = lastName;
			this.emailId = emailId;
			this.pancardNo = pancardNo;
			this.address = address;
			this.account = account;
		}

		public int getCustomerId() {
			return customerId;
		}

		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}

		public int getMobileNo() {
			return mobileNo;
		}

		public void setMobileNo(int mobileNo) {
			this.mobileNo = mobileNo;
		}

		public int getAdharNo() {
			return adharNo;
		}

		public void setAdharNo(int adharNo) {
			this.adharNo = adharNo;
		}

		public int getDateOfBirth() {
			return dateOfBirth;
		}

		public void setDateOfBirth(int dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getEmailId() {
			return emailId;
		}

		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}

		public String getPancardNo() {
			return pancardNo;
		}

		public void setPancardNo(String pancardNo) {
			this.pancardNo = pancardNo;
		}

		public Address getAddress() {
			return address;
		}

		public void setAddress(Address address) {
			this.address = address;
		}

		public Account[] getAccount() {
			return account;
		}

		public void setAccount(Account[] account) {
			this.account = account;
		}
}