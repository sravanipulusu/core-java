package com.cg.project.beans;

import java.util.List;

public class UserBean {
	private String  firstName,lastName,username,email_id,password,gender,graduation,Description;
	private List<String> communication;
	public UserBean(String firstName, String lastName, String username, String email_id, String password, String gender,
			String graduation, String description, List<String> communication) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.username = username;
		this.email_id = email_id;
		this.password = password;
		this.gender = gender;
		this.graduation = graduation;
		Description = description;
		this.communication = communication;
	}
	public UserBean(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getGraduation() {
		return graduation;
	}
	public void setGraduation(String graduation) {
		this.graduation = graduation;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public List<String> getCommunication() {
		return communication;
	}
	public void setCommunication(List<String> communication) {
		this.communication = communication;
	}
	
		
	}
