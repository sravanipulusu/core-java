package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;


@WebServlet("/SuccessServlet")
public class SuccessServlet extends HttpServlet {

	@Override
	public void destroy() {
		
		super.destroy();
	}

	@Override
	public void init() throws ServletException {
		
		super.init();
	}

	private static final long serialVersionUID = 1L;
       
  
    public SuccessServlet() {
        super();
    }

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		UserBean userBean = (UserBean) request.getAttribute("userBean");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("<div align ='center'><font color = 'green'>Welcome "+ userBean.getUsername()+ "</font>");
		out.println("</body>");
		out.println("</html>");
		
	}

}

